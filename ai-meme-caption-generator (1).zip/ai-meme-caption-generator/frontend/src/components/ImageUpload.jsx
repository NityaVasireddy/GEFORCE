import { useRef, useState } from "react";

export default function ImageUpload({ imageFile, setImageFile, description, setDescription }) {
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef(null);
  const previewUrl = imageFile ? URL.createObjectURL(imageFile) : null;

  function handleFiles(files) {
    const file = files?.[0];
    if (file && file.type.startsWith("image/")) {
      setImageFile(file);
    }
  }

  return (
    <div className="space-y-4">
      <div
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragging(false);
          handleFiles(e.dataTransfer.files);
        }}
        onClick={() => inputRef.current?.click()}
        className={`relative flex min-h-[220px] cursor-pointer flex-col items-center justify-center rounded-2xl border-4 border-dashed p-6 text-center transition-colors ${
          isDragging ? "border-grape bg-grape/10" : "border-ink bg-white"
        }`}
      >
        <input
          ref={inputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          className="hidden"
          onChange={(e) => handleFiles(e.target.files)}
        />
        {previewUrl ? (
          <div className="flex flex-col items-center gap-3">
            <img
              src={previewUrl}
              alt="Upload preview"
              className="max-h-52 rounded-xl border-2 border-ink object-contain shadow-sticker-sm"
            />
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                setImageFile(null);
              }}
              className="font-display text-sm font-semibold text-punch underline"
            >
              Remove image
            </button>
          </div>
        ) : (
          <>
            <p className="font-display text-lg font-semibold">Drop an image here</p>
            <p className="mt-1 text-sm text-ink-soft">or click to browse — JPG, PNG, WEBP, GIF (max 8MB)</p>
          </>
        )}
      </div>

      <div>
        <label htmlFor="description" className="font-display text-sm font-semibold">
          {imageFile ? "Add a hint (optional)" : "Or just describe the situation"}
        </label>
        <textarea
          id="description"
          rows={2}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="e.g. my cat knocked a plant off the shelf and is staring at me"
          className="mt-2 w-full rounded-xl border-2 border-ink bg-white p-3 text-sm shadow-sticker-sm focus:outline-none"
        />
      </div>
    </div>
  );
}
