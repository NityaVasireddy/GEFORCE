const ROTATIONS = ["-rotate-2", "rotate-2", "-rotate-3", "rotate-3", "rotate-0", "rotate-1"];

export default function ResultsSkeleton({ count = 6 }) {
  return (
    <div className="mt-10">
      <div className="flex items-baseline justify-between">
        <h2 className="font-display text-2xl font-bold">Your captions</h2>
        <span className="font-tag text-xs text-ink-soft">cooking…</span>
      </div>

      <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: count }).map((_, index) => (
          <div
            key={index}
            className={`${ROTATIONS[index % ROTATIONS.length]} flex min-h-[160px] flex-col justify-between rounded-2xl border-4 border-ink bg-white p-5 shadow-sticker`}
          >
            <div className="space-y-2">
              <div
                className="h-3 w-full animate-shimmer rounded bg-gradient-to-r from-paper-dim via-white to-paper-dim bg-[length:200%_100%]"
                style={{ animationDelay: `${index * 80}ms` }}
              />
              <div
                className="h-3 w-4/5 animate-shimmer rounded bg-gradient-to-r from-paper-dim via-white to-paper-dim bg-[length:200%_100%]"
                style={{ animationDelay: `${index * 80 + 100}ms` }}
              />
              <div
                className="h-3 w-3/5 animate-shimmer rounded bg-gradient-to-r from-paper-dim via-white to-paper-dim bg-[length:200%_100%]"
                style={{ animationDelay: `${index * 80 + 200}ms` }}
              />
            </div>
            <div className="mt-4 h-7 w-16 rounded-lg bg-paper-dim" />
          </div>
        ))}
      </div>
    </div>
  );
}
