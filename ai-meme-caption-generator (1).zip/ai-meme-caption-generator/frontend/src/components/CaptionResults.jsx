import { useState } from "react";
import { getCharLimit } from "./PlatformSelector";

const NOTE_COLORS = ["bg-zap", "bg-punch text-white", "bg-grape text-white", "bg-mint text-white", "bg-white"];
const ROTATIONS = ["-rotate-2", "rotate-2", "-rotate-3", "rotate-3", "rotate-0"];

export default function CaptionResults({
  captions,
  hashtags,
  imageSummary,
  tone,
  platform,
  favoriteTexts = new Set(),
  onToggleFavorite,
}) {
  const [copiedIndex, setCopiedIndex] = useState(null);
  const charLimit = getCharLimit(platform);

  async function handleCopy(caption, index) {
    try {
      await navigator.clipboard.writeText(caption);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 1500);
    } catch {
      // Clipboard permissions can fail silently in some sandboxed browsers.
    }
  }

  if (!captions?.length) return null;

  return (
    <div className="mt-10">
      <div className="flex items-baseline justify-between">
        <h2 className="font-display text-2xl font-bold">Your captions</h2>
        <span className="font-tag text-xs text-ink-soft">{captions.length} options</span>
      </div>

      {imageSummary && (
        <p className="mt-2 max-w-2xl text-sm text-ink-soft">
          What the AI saw: <span className="italic">"{imageSummary}"</span>
        </p>
      )}

      <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {captions.map((caption, index) => {
          const isFavorite = favoriteTexts.has(caption);
          const overLimit = charLimit ? caption.length > charLimit : false;

          return (
            <div
              key={index}
              style={{ animationDelay: `${index * 60}ms` }}
              className={`${NOTE_COLORS[index % NOTE_COLORS.length]} ${ROTATIONS[index % ROTATIONS.length]} animate-pop-in flex min-h-[160px] flex-col justify-between rounded-2xl border-4 border-ink p-5 shadow-sticker transition-transform hover:rotate-0 hover:-translate-y-1`}
            >
              <div className="flex items-start justify-between gap-2">
                <p className="font-body text-base leading-snug">{caption}</p>
                <button
                  type="button"
                  onClick={() => onToggleFavorite?.(caption)}
                  aria-pressed={isFavorite}
                  aria-label={isFavorite ? "Remove from favorites" : "Save to favorites"}
                  className={`flex-shrink-0 text-xl leading-none transition-transform hover:scale-110 ${
                    isFavorite ? "" : "opacity-50 hover:opacity-100"
                  }`}
                >
                  {isFavorite ? "★" : "☆"}
                </button>
              </div>

              <div className="mt-4 flex items-center justify-between gap-2">
                <button
                  onClick={() => handleCopy(caption, index)}
                  className="self-start rounded-lg border-2 border-ink bg-paper px-3 py-1.5 font-display text-xs font-bold text-ink transition-transform hover:-translate-y-0.5"
                >
                  {copiedIndex === index ? "Copied!" : "Copy"}
                </button>
                {charLimit && (
                  <span
                    className={`font-tag text-[10px] ${overLimit ? "font-bold text-punch" : "opacity-60"}`}
                    title={`${platform} guideline: ~${charLimit} characters`}
                  >
                    {caption.length}/{charLimit}
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {hashtags?.length > 0 && (
        <div className="mt-8">
          <p className="font-display text-sm font-semibold">Suggested hashtags</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {hashtags.map((tag, i) => (
              <button
                key={i}
                type="button"
                onClick={() => navigator.clipboard?.writeText(`#${tag.replace(/^#/, "")}`)}
                title="Click to copy"
                className="rounded-full border-2 border-ink bg-white px-3 py-1 font-tag text-xs transition-transform hover:-translate-y-0.5"
              >
                #{tag.replace(/^#/, "")}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
