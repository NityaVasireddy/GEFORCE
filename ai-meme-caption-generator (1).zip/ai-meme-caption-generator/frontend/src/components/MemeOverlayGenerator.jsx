import { useEffect, useRef, useState } from "react";

const MAX_CANVAS_WIDTH = 720;

/**
 * Renders classic top/bottom meme text (bold white, black outline) directly onto the
 * uploaded image using the Canvas API, and lets the user download the result as a PNG.
 */
export default function MemeOverlayGenerator({ imageFile, captions = [] }) {
  const canvasRef = useRef(null);
  const imgRef = useRef(null);

  const [topText, setTopText] = useState("");
  const [bottomText, setBottomText] = useState("");
  const [fontScale, setFontScale] = useState(1);
  const [isReady, setIsReady] = useState(false);
  const [downloadUrl, setDownloadUrl] = useState(null);

  // Load the uploaded image once.
  useEffect(() => {
    if (!imageFile) {
      setIsReady(false);
      return;
    }
    const url = URL.createObjectURL(imageFile);
    const img = new Image();
    img.onload = () => {
      imgRef.current = img;
      setIsReady(true);
    };
    img.src = url;
    return () => URL.revokeObjectURL(url);
  }, [imageFile]);

  // Redraw whenever text, scale, or image changes. Wait for the meme webfont to actually
  // finish loading first, otherwise the first paint silently falls back to a system font.
  useEffect(() => {
    if (!isReady) return;
    if (document?.fonts?.load) {
      document.fonts
        .load('700 48px "Anton"')
        .catch(() => {})
        .finally(draw);
    } else {
      draw();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isReady, topText, bottomText, fontScale]);

  function wrapText(ctx, text, maxWidth) {
    const words = text.split(/\s+/).filter(Boolean);
    const lines = [];
    let current = "";
    for (const word of words) {
      const test = current ? `${current} ${word}` : word;
      if (ctx.measureText(test).width > maxWidth && current) {
        lines.push(current);
        current = word;
      } else {
        current = test;
      }
    }
    if (current) lines.push(current);
    return lines;
  }

  function drawBanner(ctx, text, canvasWidth, fontSize, yPosition, align) {
    if (!text) return;
    ctx.font = `700 ${fontSize}px 'Anton', 'Impact', sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = align === "top" ? "top" : "bottom";
    ctx.lineJoin = "round";
    ctx.miterLimit = 2;
    ctx.lineWidth = Math.max(fontSize / 10, 3);
    ctx.strokeStyle = "#000000";
    ctx.fillStyle = "#ffffff";

    const maxWidth = canvasWidth * 0.92;
    const lines = wrapText(ctx, text.toUpperCase(), maxWidth);
    const lineHeight = fontSize * 1.08;

    lines.forEach((line, i) => {
      const y = align === "top" ? yPosition + i * lineHeight : yPosition - (lines.length - 1 - i) * lineHeight;
      ctx.strokeText(line, canvasWidth / 2, y);
      ctx.fillText(line, canvasWidth / 2, y);
    });
  }

  function draw() {
    const canvas = canvasRef.current;
    const img = imgRef.current;
    if (!canvas || !img) return;

    const scale = Math.min(1, MAX_CANVAS_WIDTH / img.naturalWidth);
    const width = Math.round(img.naturalWidth * scale);
    const height = Math.round(img.naturalHeight * scale);
    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, width, height);
    ctx.drawImage(img, 0, 0, width, height);

    const baseFontSize = Math.max(20, Math.round(width * 0.09 * fontScale));
    drawBanner(ctx, topText, width, baseFontSize, height * 0.06, "top");
    drawBanner(ctx, bottomText, width, baseFontSize, height * 0.96, "bottom");

    canvas.toBlob((blob) => {
      if (!blob) return;
      setDownloadUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev);
        return URL.createObjectURL(blob);
      });
    }, "image/png");
  }

  function fillFromCaption(caption) {
    // Split a caption roughly in half so long captions read as a top+bottom meme,
    // short ones just land entirely on the bottom banner (classic meme convention).
    const words = caption.split(/\s+/);
    if (words.length <= 6) {
      setTopText("");
      setBottomText(caption);
      return;
    }
    const mid = Math.ceil(words.length / 2);
    setTopText(words.slice(0, mid).join(" "));
    setBottomText(words.slice(mid).join(" "));
  }

  if (!imageFile) {
    return (
      <div className="mt-10 rounded-2xl border-2 border-dashed border-ink/40 bg-white/60 p-6 text-center">
        <p className="font-display text-sm font-semibold text-ink-soft">
          Meme text overlay needs an uploaded image
        </p>
        <p className="mt-1 text-xs text-ink-soft">
          Upload a photo above to bake generated captions directly onto it as a downloadable meme.
        </p>
      </div>
    );
  }

  return (
    <div className="mt-10 rounded-3xl border-4 border-ink bg-white p-6 shadow-sticker sm:p-8">
      <div className="flex items-baseline justify-between">
        <h2 className="font-display text-2xl font-bold">Bake it into a meme</h2>
        <span className="font-tag text-xs text-ink-soft">downloadable PNG</span>
      </div>
      <p className="mt-1 text-sm text-ink-soft">
        Classic top/bottom meme text, rendered straight onto your image — no design tool needed.
      </p>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_1fr]">
        <div className="flex items-center justify-center rounded-2xl border-2 border-ink bg-paper-dim p-3">
          {isReady ? (
            <canvas ref={canvasRef} className="max-w-full rounded-lg" />
          ) : (
            <p className="p-8 text-sm text-ink-soft">Loading image…</p>
          )}
        </div>

        <div className="space-y-4">
          {captions.length > 0 && (
            <div>
              <p className="font-display text-sm font-semibold">Quick-fill from a caption</p>
              <div className="mt-2 flex flex-wrap gap-2">
                {captions.slice(0, 6).map((c, i) => (
                  <button
                    key={i}
                    type="button"
                    onClick={() => fillFromCaption(c)}
                    className="max-w-[220px] truncate rounded-full border-2 border-ink bg-white px-3 py-1 font-tag text-[11px] transition-transform hover:-translate-y-0.5"
                    title={c}
                  >
                    #{i + 1} {c}
                  </button>
                ))}
              </div>
            </div>
          )}

          <div>
            <label htmlFor="topText" className="font-display text-sm font-semibold">
              Top text
            </label>
            <input
              id="topText"
              type="text"
              value={topText}
              onChange={(e) => setTopText(e.target.value)}
              placeholder="optional"
              className="mt-2 w-full rounded-xl border-2 border-ink bg-white p-2.5 text-sm shadow-sticker-sm focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="bottomText" className="font-display text-sm font-semibold">
              Bottom text
            </label>
            <input
              id="bottomText"
              type="text"
              value={bottomText}
              onChange={(e) => setBottomText(e.target.value)}
              placeholder="the punchline"
              className="mt-2 w-full rounded-xl border-2 border-ink bg-white p-2.5 text-sm shadow-sticker-sm focus:outline-none"
            />
          </div>

          <div>
            <label htmlFor="fontScale" className="font-display text-sm font-semibold">
              Text size
            </label>
            <input
              id="fontScale"
              type="range"
              min={0.6}
              max={1.6}
              step={0.1}
              value={fontScale}
              onChange={(e) => setFontScale(Number(e.target.value))}
              className="mt-2 w-full accent-grape"
            />
          </div>

          <a
            href={downloadUrl || undefined}
            download="capshun-meme.png"
            aria-disabled={!downloadUrl}
            className={`inline-block w-full rounded-xl border-4 border-ink bg-mint py-3 text-center font-display text-lg font-bold text-white shadow-sticker transition-transform hover:-translate-y-0.5 ${
              !downloadUrl ? "pointer-events-none opacity-60" : ""
            }`}
          >
            Download meme PNG
          </a>
        </div>
      </div>
    </div>
  );
}
