const PLATFORMS = [
  { id: "instagram", label: "Instagram", icon: "📸" },
  { id: "twitter/x", label: "Twitter / X", icon: "🐦" },
  { id: "tiktok", label: "TikTok", icon: "🎵" },
  { id: "linkedin", label: "LinkedIn", icon: "💼" },
  { id: "reddit", label: "Reddit", icon: "👽" },
];

const CHAR_LIMITS = {
  instagram: 2200,
  "twitter/x": 240,
  tiktok: 150,
  linkedin: 3000,
  reddit: 300,
};

export function getCharLimit(platform) {
  return CHAR_LIMITS[platform] ?? null;
}

export default function PlatformSelector({ platform, setPlatform }) {
  return (
    <div>
      <p className="font-display text-sm font-semibold">Platform</p>
      <div className="mt-2 grid grid-cols-3 gap-2 sm:grid-cols-5">
        {PLATFORMS.map((p) => (
          <button
            key={p.id}
            type="button"
            aria-pressed={platform === p.id}
            onClick={() => setPlatform(p.id)}
            className={`flex flex-col items-center gap-1 rounded-xl border-2 border-ink px-2 py-2 font-display text-xs font-semibold transition-transform hover:-translate-y-0.5 ${
              platform === p.id ? "bg-ink text-paper shadow-sticker-sm" : "bg-white"
            }`}
          >
            <span aria-hidden="true" className="text-base leading-none">
              {p.icon}
            </span>
            {p.label}
          </button>
        ))}
      </div>
    </div>
  );
}
