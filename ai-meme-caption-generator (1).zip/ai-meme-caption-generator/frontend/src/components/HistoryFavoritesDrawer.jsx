import { useState } from "react";

export default function HistoryFavoritesDrawer({
  isOpen,
  onClose,
  favorites,
  history,
  onRemoveFavorite,
  onRestoreHistory,
  onRemoveHistory,
  onClearHistory,
}) {
  const [tab, setTab] = useState("favorites");

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div
        className="absolute inset-0 bg-ink/40 backdrop-blur-[1px]"
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-label="Favorites and history"
        className="relative flex h-full w-full max-w-md flex-col border-l-4 border-ink bg-paper shadow-2xl animate-slide-in"
      >
        <div className="flex items-center justify-between border-b-4 border-ink p-5">
          <h2 className="font-display text-xl font-bold">Saved stuff</h2>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close panel"
            className="rounded-lg border-2 border-ink bg-white px-3 py-1.5 font-display text-sm font-bold transition-transform hover:-translate-y-0.5"
          >
            ✕
          </button>
        </div>

        <div className="flex gap-2 border-b-2 border-ink/20 p-4">
          <button
            type="button"
            onClick={() => setTab("favorites")}
            className={`flex-1 rounded-xl border-2 border-ink px-3 py-2 font-display text-sm font-semibold transition-transform hover:-translate-y-0.5 ${
              tab === "favorites" ? "bg-zap shadow-sticker-sm" : "bg-white"
            }`}
          >
            ★ Favorites ({favorites.length})
          </button>
          <button
            type="button"
            onClick={() => setTab("history")}
            className={`flex-1 rounded-xl border-2 border-ink px-3 py-2 font-display text-sm font-semibold transition-transform hover:-translate-y-0.5 ${
              tab === "history" ? "bg-grape text-white shadow-sticker-sm" : "bg-white"
            }`}
          >
            History ({history.length})
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 scrollbar-thin">
          {tab === "favorites" && (
            <>
              {favorites.length === 0 && (
                <p className="text-sm text-ink-soft">
                  No favorites yet — tap the star on any caption to save it here.
                </p>
              )}
              <div className="space-y-3">
                {favorites.map((f) => (
                  <div
                    key={f.id}
                    className="rounded-xl border-2 border-ink bg-white p-3 shadow-sticker-sm"
                  >
                    <p className="text-sm">{f.text}</p>
                    <div className="mt-2 flex items-center justify-between">
                      <span className="font-tag text-[10px] uppercase text-ink-soft">
                        {f.tone} · {f.platform}
                      </span>
                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => navigator.clipboard?.writeText(f.text)}
                          className="rounded-lg border-2 border-ink bg-paper px-2 py-1 font-display text-[11px] font-bold transition-transform hover:-translate-y-0.5"
                        >
                          Copy
                        </button>
                        <button
                          type="button"
                          onClick={() => onRemoveFavorite(f.id)}
                          className="rounded-lg border-2 border-ink bg-punch px-2 py-1 font-display text-[11px] font-bold text-white transition-transform hover:-translate-y-0.5"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}

          {tab === "history" && (
            <>
              {history.length === 0 && (
                <p className="text-sm text-ink-soft">
                  Your last few generations will show up here so you can revisit them.
                </p>
              )}
              {history.length > 0 && (
                <button
                  type="button"
                  onClick={onClearHistory}
                  className="mb-3 font-display text-xs font-semibold text-punch underline"
                >
                  Clear all history
                </button>
              )}
              <div className="space-y-3">
                {history.map((h) => (
                  <div
                    key={h.id}
                    className="rounded-xl border-2 border-ink bg-white p-3 shadow-sticker-sm"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-tag text-[10px] uppercase text-ink-soft">
                        {h.tone} · {h.platform} · {h.captions.length} options
                      </span>
                      <span className="font-tag text-[10px] text-ink-soft">
                        {new Date(h.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                    {h.imageSummary && (
                      <p className="mt-1 text-xs italic text-ink-soft">"{h.imageSummary}"</p>
                    )}
                    <p className="mt-2 line-clamp-2 text-sm">{h.captions[0]}</p>
                    <div className="mt-2 flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          onRestoreHistory(h);
                          onClose();
                        }}
                        className="rounded-lg border-2 border-ink bg-mint px-2 py-1 font-display text-[11px] font-bold text-white transition-transform hover:-translate-y-0.5"
                      >
                        View again
                      </button>
                      <button
                        type="button"
                        onClick={() => onRemoveHistory(h.id)}
                        className="rounded-lg border-2 border-ink bg-paper px-2 py-1 font-display text-[11px] font-bold transition-transform hover:-translate-y-0.5"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
