// Lightweight localStorage-backed persistence for favorites and generation history.
// No backend/database needed for MVP — matches the project brief's guidance that a
// database is only required "if implementing save/favorites; otherwise skip for MVP".
// Client-side storage keeps the feature real (persists across sessions) without adding
// backend surface area or user accounts.

const FAVORITES_KEY = "capshun:favorites";
const HISTORY_KEY = "capshun:history";
const MAX_HISTORY = 8;

function safeParse(raw, fallback) {
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

function read(key) {
  if (typeof window === "undefined") return [];
  return safeParse(window.localStorage.getItem(key), []);
}

function write(key, value) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // Storage can fail (quota, private browsing) — fail silently, feature just won't persist.
  }
}

// ---------- Favorites ----------

export function getFavorites() {
  return read(FAVORITES_KEY);
}

export function isFavorite(captionText) {
  return getFavorites().some((f) => f.text === captionText);
}

export function toggleFavorite({ text, tone, platform }) {
  const current = getFavorites();
  const existingIndex = current.findIndex((f) => f.text === text);

  let next;
  if (existingIndex >= 0) {
    next = current.filter((_, i) => i !== existingIndex);
  } else {
    next = [
      { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, text, tone, platform, savedAt: Date.now() },
      ...current,
    ];
  }
  write(FAVORITES_KEY, next);
  return next;
}

export function removeFavorite(id) {
  const next = getFavorites().filter((f) => f.id !== id);
  write(FAVORITES_KEY, next);
  return next;
}

// ---------- History ----------

export function getHistory() {
  return read(HISTORY_KEY);
}

export function addHistoryEntry(entry) {
  const current = getHistory();
  const next = [
    { id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, createdAt: Date.now(), ...entry },
    ...current,
  ].slice(0, MAX_HISTORY);
  write(HISTORY_KEY, next);
  return next;
}

export function removeHistoryEntry(id) {
  const next = getHistory().filter((h) => h.id !== id);
  write(HISTORY_KEY, next);
  return next;
}

export function clearHistory() {
  write(HISTORY_KEY, []);
  return [];
}
