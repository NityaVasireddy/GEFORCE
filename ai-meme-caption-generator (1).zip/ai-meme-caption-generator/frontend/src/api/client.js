const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:5000";

export async function generateCaptions({ imageFile, description, tone, platform, count }) {
  const formData = new FormData();
  if (imageFile) formData.append("image", imageFile);
  if (description) formData.append("description", description);
  formData.append("tone", tone);
  formData.append("platform", platform);
  formData.append("count", String(count));

  const response = await fetch(`${API_BASE_URL}/api/generate/captions`, {
    method: "POST",
    body: formData,
  });

  const data = await response.json();

  if (!response.ok) {
    throw new Error(data.error || "Failed to generate captions.");
  }

  return data;
}

export async function fetchTemplates() {
  const response = await fetch(`${API_BASE_URL}/api/generate/templates`);
  if (!response.ok) throw new Error("Failed to load meme templates.");
  return response.json();
}
