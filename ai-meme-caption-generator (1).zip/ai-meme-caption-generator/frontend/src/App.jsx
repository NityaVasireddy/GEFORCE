import { useEffect, useState } from "react";
import Header from "./components/Header";
import ImageUpload from "./components/ImageUpload";
import ToneSelector from "./components/ToneSelector";
import PlatformSelector from "./components/PlatformSelector";
import CaptionResults from "./components/CaptionResults";
import MemeTemplateSuggestions from "./components/MemeTemplateSuggestions";
import MemeOverlayGenerator from "./components/MemeOverlayGenerator";
import ResultsSkeleton from "./components/ResultsSkeleton";
import HistoryFavoritesDrawer from "./components/HistoryFavoritesDrawer";
import { generateCaptions } from "./api/client";
import {
  getFavorites,
  toggleFavorite,
  removeFavorite,
  getHistory,
  addHistoryEntry,
  removeHistoryEntry,
  clearHistory,
} from "./utils/storage";

const EXAMPLE_PROMPTS = [
  "my cat knocked a plant off the shelf and is staring at me like I did it",
  "showed up to the meeting and realized it was cancelled an hour ago",
  "my houseplant somehow survived another month of me forgetting it exists",
  "ordered iced coffee in a snowstorm and have zero regrets",
];

export default function App() {
  const [imageFile, setImageFile] = useState(null);
  const [description, setDescription] = useState("");
  const [tone, setTone] = useState("humorous");
  const [platform, setPlatform] = useState("instagram");
  const [count, setCount] = useState(6);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  const [favorites, setFavorites] = useState([]);
  const [history, setHistory] = useState([]);
  const [isPanelOpen, setIsPanelOpen] = useState(false);

  useEffect(() => {
    setFavorites(getFavorites());
    setHistory(getHistory());
  }, []);

  async function handleGenerate() {
    setError(null);

    if (!imageFile && !description.trim()) {
      setError("Upload an image or describe the situation first.");
      return;
    }

    setIsLoading(true);
    setResult(null);
    try {
      const data = await generateCaptions({ imageFile, description, tone, platform, count });
      setResult(data);
      const updatedHistory = addHistoryEntry({
        captions: data.captions,
        hashtags: data.hashtags,
        imageSummary: data.imageSummary,
        templateMatches: data.templateMatches,
        tone,
        platform,
      });
      setHistory(updatedHistory);
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }

  function handleToggleFavorite(text) {
    const updated = toggleFavorite({ text, tone, platform });
    setFavorites(updated);
  }

  function handleRemoveFavorite(id) {
    setFavorites(removeFavorite(id));
  }

  function handleRestoreHistory(entry) {
    setResult({
      captions: entry.captions,
      hashtags: entry.hashtags,
      imageSummary: entry.imageSummary,
      templateMatches: entry.templateMatches,
    });
    setTone(entry.tone);
    setPlatform(entry.platform);
    setError(null);
    document.getElementById("generator")?.scrollIntoView({ behavior: "smooth" });
  }

  function handleRemoveHistory(id) {
    setHistory(removeHistoryEntry(id));
  }

  function handleClearHistory() {
    setHistory(clearHistory());
  }

  function fillExample() {
    const pick = EXAMPLE_PROMPTS[Math.floor(Math.random() * EXAMPLE_PROMPTS.length)];
    setDescription(pick);
    setImageFile(null);
  }

  const favoriteTexts = new Set(favorites.map((f) => f.text));

  return (
    <div className="min-h-screen">
      <Header savedCount={favorites.length + history.length} onOpenSaved={() => setIsPanelOpen(true)} />

      {/* Hero */}
      <section className="mx-auto max-w-5xl px-6 pb-4 pt-14">
        <div className="max-w-2xl">
          <h1 className="font-display text-4xl font-bold leading-tight sm:text-5xl">
            Turn any photo into a caption people actually stop scrolling for.
          </h1>
          <p className="mt-4 text-lg text-ink-soft">
            Upload a picture or describe what happened. Pick a tone and platform. Get a batch of
            genuinely different captions, matching hashtags, and the meme format your post already
            looks like — in one shot.
          </p>
        </div>
      </section>

      {/* Generator */}
      <section id="generator" className="mx-auto max-w-5xl px-6 py-8">
        <div className="rounded-3xl border-4 border-ink bg-white p-6 shadow-sticker sm:p-8">
          <div className="grid gap-8 lg:grid-cols-[1.1fr_1fr]">
            <div className="space-y-3">
              <ImageUpload
                imageFile={imageFile}
                setImageFile={setImageFile}
                description={description}
                setDescription={setDescription}
              />
              <button
                type="button"
                onClick={fillExample}
                className="font-display text-xs font-semibold text-grape underline underline-offset-2"
              >
                🎲 Try a random example instead
              </button>
            </div>

            <div className="space-y-6">
              <ToneSelector tone={tone} setTone={setTone} />
              <PlatformSelector platform={platform} setPlatform={setPlatform} />

              <div>
                <label htmlFor="count" className="font-display text-sm font-semibold">
                  How many options: {count}
                </label>
                <input
                  id="count"
                  type="range"
                  min={5}
                  max={8}
                  value={count}
                  onChange={(e) => setCount(Number(e.target.value))}
                  className="mt-2 w-full accent-grape"
                />
              </div>

              <button
                onClick={handleGenerate}
                disabled={isLoading}
                className="w-full rounded-xl border-4 border-ink bg-zap py-3 font-display text-lg font-bold shadow-sticker transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {isLoading ? "Cooking up captions…" : result ? "Regenerate captions" : "Generate captions"}
              </button>

              {error && (
                <p role="alert" className="rounded-xl border-2 border-punch bg-punch/10 p-3 text-sm font-medium text-punch">
                  {error}
                </p>
              )}
            </div>
          </div>
        </div>

        {isLoading && <ResultsSkeleton count={count} />}

        {!isLoading && result && (
          <>
            <CaptionResults
              captions={result.captions}
              hashtags={result.hashtags}
              imageSummary={result.imageSummary}
              tone={tone}
              platform={platform}
              favoriteTexts={favoriteTexts}
              onToggleFavorite={handleToggleFavorite}
            />
            <MemeTemplateSuggestions templates={result.templateMatches} />
            <MemeOverlayGenerator imageFile={imageFile} captions={result.captions} />
          </>
        )}
      </section>

      <footer className="mx-auto max-w-5xl px-6 py-10 text-sm text-ink-soft">
        Built for the hackathon — powered by Google Gemini. Favorites and history are saved
        locally in your browser.
      </footer>

      <HistoryFavoritesDrawer
        isOpen={isPanelOpen}
        onClose={() => setIsPanelOpen(false)}
        favorites={favorites}
        history={history}
        onRemoveFavorite={handleRemoveFavorite}
        onRestoreHistory={handleRestoreHistory}
        onRemoveHistory={handleRemoveHistory}
        onClearHistory={handleClearHistory}
      />
    </div>
  );
}
