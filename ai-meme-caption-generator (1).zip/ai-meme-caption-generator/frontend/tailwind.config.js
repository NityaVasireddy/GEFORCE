/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#14131A",
        "ink-soft": "#2B2A33",
        paper: "#FFF9EE",
        "paper-dim": "#F4EEDE",
        zap: "#FFCB3C",
        punch: "#FF5C4D",
        grape: "#7B5CFA",
        mint: "#37B893",
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        body: ["'Inter'", "sans-serif"],
        tag: ["'JetBrains Mono'", "monospace"],
      },
      rotate: {
        "-3": "-3deg",
        "-2": "-2deg",
        "2": "2deg",
        "3": "3deg",
      },
      boxShadow: {
        sticker: "6px 6px 0px 0px rgba(20,19,26,1)",
        "sticker-sm": "3px 3px 0px 0px rgba(20,19,26,1)",
      },
      keyframes: {
        popIn: {
          "0%": { opacity: "0", transform: "translateY(10px) scale(0.96)" },
          "100%": { opacity: "1", transform: "translateY(0) scale(1)" },
        },
        slideIn: {
          "0%": { transform: "translateX(100%)" },
          "100%": { transform: "translateX(0)" },
        },
        shimmer: {
          "0%": { backgroundPosition: "-200% 0" },
          "100%": { backgroundPosition: "200% 0" },
        },
      },
      animation: {
        "pop-in": "popIn 0.35s ease-out both",
        "slide-in": "slideIn 0.25s ease-out both",
        shimmer: "shimmer 1.6s linear infinite",
      },
    },
  },
  plugins: [],
};
