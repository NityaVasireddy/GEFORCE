# Capshun — Project Showcase / Landing Page Content

Content and layout structure for a project showcase page, ready to drop into any site builder or
the existing React app as a marketing route.

---

## Hero Section

**Headline:**
> Turn any photo into a caption people actually stop scrolling for.

**Subheadline (elevator pitch):**
> Capshun reads your image, understands the moment, and writes a full batch of tones-and-platform
> matched captions, hashtags, and meme-format matches — before you'd have finished typing one
> caption yourself.

**Primary CTA:** `Try the live demo`  → links to deployed Vercel URL
**Secondary CTA:** `View on GitHub` → links to repo

**Visual treatment:** Show three rotated "sticky note" caption cards behind the headline, each in
a different accent color (zap yellow, punch coral, grape purple), as if pulled from a real
generated batch — this is the most characteristic visual the product produces, so it belongs in
the hero rather than a generic product screenshot.

---

## Problem vs. Solution

**The problem:**
Creators and social media managers post daily, sometimes across four or five accounts. Writing
copy that's actually funny or on-brand for every single post — every day — is a real bottleneck.
Generic AI writers produce bland text; manual meme tools don't write anything at all.

**The solution:**
One upload, one click, a full batch of genuinely different options: tone-matched, platform-aware,
and paired with the meme format the content already resembles. Content creation goes from a
blank-page stall to a 10-second decision between options that are already good.

**Framing for the page:** present as a two-column "before / after" — left column: a content
calendar with empty caption fields and a clock icon; right column: the same calendar filled in,
five minutes later.

---

## Interactive Feature Highlights

1. **Multi-platform output**
   *One image, four different personalities.* The same photo produces a punchy one-liner for
   Twitter/X, a polished observation for LinkedIn, a casual line for Instagram, and a dry
   Reddit-style title — because what lands on one platform falls flat on another.

2. **Tone controls that actually shift**
   *Sarcastic isn't just "less nice."* Each tone comes with its own vocabulary and rhythm, so
   switching from Wholesome to Sarcastic on the same photo produces a visibly different joke, not
   a reworded one.

3. **AI multimodal vision analysis**
   *It actually looks at the picture.* Capshun doesn't caption based on a filename or a guess —
   Gemini's vision model reads what's actually happening in the frame, then writes from there.

4. **Meme format matching**
   *Know what you're posting into.* Every batch comes with 2–3 well-known meme formats your
   content already resembles, pulled from a curated list of internet classics — so you know
   exactly how to frame it before you post.

---

## Live Demo Walkthrough Guide (for judges)

1. Open the live demo URL and let the page load — no login required.
2. Click the upload area and drop in any photo (a pet, a messy desk, a relatable moment — the
   funnier or more chaotic, the better the demo).
3. Leave the optional hint field blank, or add one short line of context if the photo is ambiguous.
4. Select **Sarcastic** as the tone and **Instagram** as the platform, then click **Generate captions**.
5. Review the batch of options — note that each one takes a different angle rather than
   rewording the same joke.
6. Change the tone to **Wholesome** on the same image and regenerate — compare the two batches
   side by side to see the tone actually shift.
7. Scroll to the **This fits these formats** section to see the matched meme templates and why
   each one was chosen.
8. Click **Copy** on a favorite caption to show the one-click, ready-to-post final step.

**Suggested demo images:** a pet mid-mischief, an obviously messy home office, or a half-eaten
snack next to a laptop — situations judges will immediately recognize.
