import { GoogleGenAI } from "@google/genai";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const memeTemplates = JSON.parse(
  fs.readFileSync(path.join(__dirname, "../data/memeTemplates.json"), "utf-8")
);

let genAI = null;
function getClient() {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error(
      "GEMINI_API_KEY is not set. Add it to your .env file before starting the server."
    );
  }
  if (!genAI) {
    genAI = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
  }
  return genAI;
}

const MODEL = process.env.GEMINI_MODEL || "gemini-2.0-flash";

const TONE_GUIDES = {
  sarcastic:
    "Dry, deadpan, eye-rolling wit. Use understatement and irony. Never explain the joke.",
  wholesome:
    "Warm, kind, feel-good. Genuine positivity without being cheesy or corny.",
  professional:
    "Polished, clear, brand-safe copy suitable for a business account. Confident but not stiff.",
  genz:
    "Internet-native, current slang, chaotic energy, lowercase-leaning, playful exaggeration. Avoid slang that has already gone stale.",
  humorous:
    "Punchy, silly, clever wordplay. Aim for an actual laugh, not just cute.",
  inspirational:
    "Motivational and uplifting, short and quotable, without sounding like a generic quote poster.",
};

const PLATFORM_GUIDES = {
  instagram:
    "Caption length can be 1-3 short lines. Casual, visual-first, light emoji use is fine.",
  "twitter/x":
    "Keep it under 240 characters, punchy, built to be read in one glance, minimal hashtags.",
  twitter:
    "Keep it under 240 characters, punchy, built to be read in one glance, minimal hashtags.",
  tiktok:
    "Short, energetic, written like on-screen text or a hook line, can reference a trend or sound.",
  linkedin:
    "Professional tone even if witty, no meme slang, framed as an observation or insight, no emoji spam.",
  reddit:
    "Written like a title or top comment: dry, self-aware, no hashtags, no emoji, plain text humor.",
};

function buildPrompt({ description, tone, platform, count }) {
  const toneGuide = TONE_GUIDES[tone?.toLowerCase()] || TONE_GUIDES.humorous;
  const platformGuide =
    PLATFORM_GUIDES[platform?.toLowerCase()] || PLATFORM_GUIDES.instagram;

  return `You are a social media copywriter who deeply understands meme culture and internet humor.

TASK: Generate exactly ${count} distinct caption options for a social media post.

${description ? `SITUATION / IMAGE CONTEXT PROVIDED BY USER: "${description}"` : "An image is attached below — base the captions on what is actually happening in it."}

TONE: ${tone} — ${toneGuide}
PLATFORM: ${platform} — ${platformGuide}

RULES:
- Each of the ${count} captions must be genuinely different in angle, structure, or joke — not minor rewordings of each other.
- Stay strictly in the requested tone; make the tone shift obvious if compared to a different tone on the same subject.
- Never produce offensive, discriminatory, sexual, hateful, or NSFW content. If the image/description is sensitive, keep humor gentle and safe.
- Do not use generic filler like "when you..." for every single caption — vary the structure.
- No markdown, no numbering, no quotation marks around captions.

Also suggest relevant hashtags (3-6) that fit the platform and content.

Respond ONLY with valid JSON, no preamble, no code fences, matching exactly this shape:
{
  "captions": ["caption 1", "caption 2", "..."],
  "hashtags": ["tag1", "tag2", "..."],
  "imageSummary": "one short sentence describing what you saw/understood about the subject"
}`;
}

function buildMemeTemplatePrompt({ description, imageSummary }) {
  const list = memeTemplates
    .map((t) => `- id: "${t.id}" | ${t.name}: ${t.structure} (best for: ${t.bestFor})`)
    .join("\n");

  const context = imageSummary || description || "no additional context given";

  return `You are matching a social media post to well-known meme formats.

CONTEXT ABOUT THE POST: "${context}"

CURATED MEME FORMAT LIST (choose ONLY from this list, never invent a new one):
${list}

TASK: Pick the 2-3 formats from the list above that best fit this context, ranked best-first.

Respond ONLY with valid JSON, no preamble, no code fences, matching exactly this shape:
{
  "matches": [
    { "id": "template-id-from-list", "reason": "one short sentence on why it fits" }
  ]
}`;
}

function extractJson(text) {
  if (!text) throw new Error("Empty response from Gemini.");
  let cleaned = text.trim();
  cleaned = cleaned.replace(/^```(json)?/i, "").replace(/```$/, "").trim();
  const firstBrace = cleaned.indexOf("{");
  const lastBrace = cleaned.lastIndexOf("}");
  if (firstBrace === -1 || lastBrace === -1) {
    throw new Error("Gemini response did not contain JSON.");
  }
  const jsonSlice = cleaned.slice(firstBrace, lastBrace + 1);
  return JSON.parse(jsonSlice);
}

/**
 * Generates caption options (and hashtags) from an optional image buffer and/or text description.
 */
export async function generateCaptions({
  imageBuffer,
  mimeType,
  description,
  tone = "humorous",
  platform = "instagram",
  count = 6,
}) {
  const client = getClient();
  const parts = [{ text: buildPrompt({ description, tone, platform, count }) }];

  if (imageBuffer) {
    parts.push({
      inlineData: {
        mimeType: mimeType || "image/jpeg",
        data: imageBuffer.toString("base64"),
      },
    });
  }

  const response = await client.models.generateContent({
    model: MODEL,
    contents: [{ role: "user", parts }],
    config: {
      temperature: 0.95,
      maxOutputTokens: 1024,
      safetySettings: [
        { category: "HARM_CATEGORY_HARASSMENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
        { category: "HARM_CATEGORY_HATE_SPEECH", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
        { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
        { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
      ],
    },
  });

  const text = response.text;
  const parsed = extractJson(text);

  if (!Array.isArray(parsed.captions) || parsed.captions.length === 0) {
    throw new Error("Gemini did not return any captions.");
  }

  return {
    captions: parsed.captions.slice(0, count),
    hashtags: Array.isArray(parsed.hashtags) ? parsed.hashtags : [],
    imageSummary: parsed.imageSummary || null,
  };
}

/**
 * Matches the post context against the curated meme template list.
 */
export async function suggestMemeTemplates({ description, imageSummary }) {
  const client = getClient();
  const prompt = buildMemeTemplatePrompt({ description, imageSummary });

  const response = await client.models.generateContent({
    model: MODEL,
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    config: { temperature: 0.4, maxOutputTokens: 512 },
  });

  const parsed = extractJson(response.text);
  const matches = Array.isArray(parsed.matches) ? parsed.matches : [];

  return matches
    .map((m) => {
      const template = memeTemplates.find((t) => t.id === m.id);
      if (!template) return null;
      return { ...template, reason: m.reason || "" };
    })
    .filter(Boolean)
    .slice(0, 3);
}

export function getAllMemeTemplates() {
  return memeTemplates;
}
